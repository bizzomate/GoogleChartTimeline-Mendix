CREATE TABLE "testsuite$status" (
	"id" BIGINT NOT NULL,
	"color" VARCHAR_IGNORECASE(200) NULL,
	PRIMARY KEY("id"));
INSERT INTO "mendixsystem$entity" ("id", 
"entity_name", 
"table_name")
 VALUES ('55ff38c1-16a7-439d-b1c9-a723bff35748', 
'TestSuite.Status', 
'testsuite$status');
INSERT INTO "mendixsystem$attribute" ("id", 
"entity_id", 
"attribute_name", 
"column_name", 
"type", 
"length", 
"default_value", 
"is_auto_number")
 VALUES ('74548f5c-d889-4305-9e91-36d5f7355afd', 
'55ff38c1-16a7-439d-b1c9-a723bff35748', 
'Color', 
'color', 
30, 
200, 
'', 
false);
CREATE TABLE "testsuite$dataitem_status" (
	"testsuite$dataitemid" BIGINT NOT NULL,
	"testsuite$statusid" BIGINT NOT NULL,
	PRIMARY KEY("testsuite$dataitemid","testsuite$statusid"));
CREATE INDEX "idx_testsuite$dataitem_status_testsuite$status_testsuite$dataitem" ON "testsuite$dataitem_status" ("testsuite$statusid" ASC,"testsuite$dataitemid" ASC);
INSERT INTO "mendixsystem$association" ("id", 
"association_name", 
"table_name", 
"parent_entity_id", 
"child_entity_id", 
"parent_column_name", 
"child_column_name", 
"index_name")
 VALUES ('37f18909-fad3-4ce8-a6a7-22f87b7d8757', 
'TestSuite.dataItem_Status', 
'testsuite$dataitem_status', 
'c33e29ae-8f68-4703-a0a6-cbeba7f92a3f', 
'55ff38c1-16a7-439d-b1c9-a723bff35748', 
'testsuite$dataitemid', 
'testsuite$statusid', 
'idx_testsuite$dataitem_status_testsuite$status_testsuite$dataitem');
UPDATE "mendixsystem$version"
 SET "versionnumber" = '4.2', 
"lastsyncdate" = '20190531 08:25:01';
